#!/bin/bash

echo
echo "V2x RSU Updating..."
echo

